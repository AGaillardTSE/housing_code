/* *************************************** */
//      Wealth Taxation with Housing       //
/*                May 2017                 */
//           Alexandre Gaillard            //
/* *************************************** */



/*********************/
// FUNCTION TAXATION //
/*********************/

double HSV(const double income)
{
    double taxes;

    taxes = income - lambda*pow(income,1-tau_hsv);

    return (taxes);
}


/********************/
// MAINTENANCE COST //
/********************/

double Mcost(const double hval)
{
    double cost;
    
    cost = hval*deltaH*price;
    
    return (cost);
}





/****************************************/
// FUNCTION CONSUMPTION (OR MAX WEALTH) //
/****************************************/



double cashonhand(const int kgrid, const int ygrid, const int hgrid, const int hnext, const int sgrid){
double Is, Ib, Ik, standard, renthousing, housingSorB, maintenance, taxH, taxK;

if(K[kgrid] >= 0){Ik = 1;}
if(H[hgrid] > H[hnext]){Is = 1; Ib = 0;}
if(H[hgrid] < H[hnext]){Ib = 1; Is = 0;}

standard = (1+irateS)*K[kgrid]*Ik + (1+irateB)*K[kgrid]*(1 - Ik) + wage*Y[ygrid]; // - HSV(Y[ygrid])
renthousing = (1.0-tau_r)*rent*(H[hnext] - S[sgrid]);
housingSorB = price*(H[hgrid] - H[hnext]) - Ib*tau_b*price*H[hnext] - Is*price*tau_s*price*H[hnext];
maintenance = deltaH*price*H[hnext];
taxH = tau_h*price*H[hnext];
taxK = tau_k*irateS*K[kgrid]*Ik;

//printf("COH: %f %f %f %f %f %f", standard,renthousing,housingSorB,maintenance,taxH,taxK);getchar();

return(standard + renthousing + housingSorB - maintenance - taxH - taxK); // may be negative for some values

}





