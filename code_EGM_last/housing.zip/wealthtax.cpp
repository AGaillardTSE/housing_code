/* *************************************** */
// Insuring Entrepreneurial Downside risk? //
/*                  May 2017               */
// Sumudu Kankanamge, Alexandre Gaillard   //
/* *************************************** */




/**********************/
/**     STRUCTURE   ***/
/**********************/

struct params_H_pb
{
    double *VFnextST, cohST;
    int hnextST, ygridST, svalST;
};







/* ********* */
/* CPP FILES */
/* ********* */

// HEADER
#include "wealthtax.h"

// USEFUL
#include "useful.cpp"
#include "/Users/alexandregaillard/Documents/Compiler/lib/libperso/tauchen.cpp"

///// MY OPTIMIZATION FUNCTIONS //////
#include "/Users/alexandregaillard/Documents/Compiler/lib/optimfun/entunemployed/zbrentNEW.cpp"   /// to find minimum sequentially ///
#include "/Users/alexandregaillard/Documents/Compiler/lib/optimfun/entunemployed/mymngolden.cpp"      /// to find minimum /////

// CPP FILES //
#include "budget_constraint.cpp"
#include "VFI.cpp"







int main(int argc, char* argv[])
{


/********************/
/** INITIALIZATION **/
/********************/

int igrid, ygrid, hgrid, *house, yy;




// PROCESS OF Y //
//tauchenfun(rhoy, 1.0, 0.0, sigy, Y, PI_tot);
//inv_distri(PI_inv, PI_tot);

for(ygrid = 0; ygrid < maxygrid; ygrid++){
//    Y[ygrid] = exp(Y[ygrid]);
    printf("%f\t", Y[ygrid]);
}
printf("\n");
printf("\n");
for(ygrid = 0; ygrid < maxygrid; ygrid++){
    for(yy = 0; yy < maxygrid; yy++){
        printf("%f\t", PI_tot[ygrid][yy]);
    }
    printf("\n");
}
printf("\n");
for(ygrid = 0; ygrid < maxygrid; ygrid++){
    printf("%f\t", PI_inv[ygrid]);
}
printf("\n");getchar();





// VALUE AND POLICY FUNCTIONS //
double *VF, *Kopti;
int *Hopti, *Sopti;

VF = (double *) calloc((ifulldim), sizeof(double));
Kopti = (double *) calloc((ifulldim), sizeof(double));
Hopti = (int *) calloc((ifulldim), sizeof(int));
Sopti = (int *) calloc((ifulldim), sizeof(int));



// HOUSING GRID //
H[0] = 0.0;
S[0] = 0.5;
for(hgrid=1; hgrid<maxhgrid; hgrid++){
    H[hgrid] = linspace(GridminH,GridmaxH,maxhgrid,hgrid);
    S[hgrid] = H[hgrid];
}
for(hgrid=0; hgrid<maxhgrid; hgrid++){
    printf("%f\t", H[hgrid]);
}
printf("\n");





// BOUNDS //
Gridmin = -(1-theta)*price*H[maxhgrid-1]-0.01;
printf("Gridmin: %f\n", Gridmin);

// WEALTH GRID AND INITIALIZE VALUES //
for(igrid=0;igrid<maxigrid;igrid++)
{
    K[igrid] = linspace(Gridmin,Gridmax,maxigrid,igrid);
    
    //printf("%f", K[igrid]);getchar();
    
    for(int ygrid = 0.0; ygrid < maxygrid; ygrid ++)
    {
        for(int hgrid = 0.0; hgrid < maxhgrid; hgrid++) {
            VF[inx(igrid,hgrid,ygrid)]=-10000.0;
        }
    }
}


VFI(VF, Kopti, Hopti, Sopti);


printf("PROGRAM FINISHED"); getchar();

    
return 0;
}




