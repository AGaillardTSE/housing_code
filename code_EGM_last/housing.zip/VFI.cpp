/* *************************************** */
//      Wealth Taxation with Housing       //
/*                May 2017                 */
//           Alexandre Gaillard            //
/* *************************************** */



/*******************************************/
// STAGE 1: COMPUTE THE OPTIMAL k GIVEN H' //
/*******************************************/

// Probably, is better to separate into two golden rules: [bar(k), 0] and [0, maxgrid] //
// two bounds for k' (by above): =min(coh-stuff, coh2)

double foc(const double kval, void * params) // look for the optimal k, that can be out of the grid //
{
    struct params_H_pb *focparams= (struct params_H_pb *) params;
    
    double *VFnext=focparams->VFnextST;
    double coh=focparams->cohST;
    int hnext=focparams->hnextST;
    int ygrid=focparams->ygridST;
    int sval=focparams->svalST;
    
    double cons,xgrid,dxgrid,valfoc;
    double temp_vf;
    
    int index1, index2, ixgrid;
    

    
    // SEARCH CONSUMPTION LEVEL //
    cons = coh - kval;
    
    
    // SAVING AND NEXT VALUE FUNCTION //
    //xgrid = invexpspace(kval,Gridmin,Gridmax,Echelle1,maxigrid);
    xgrid = invlinspace(Gridmin,Gridmax,maxigrid,kval);
    dxgrid = weightinter(kval, xgrid, &ixgrid, K, maxigrid);
    
    //printf("%f %f %f \n", xgrid, dxgrid, kval);
    
    // VERIFICATIONS //
    if ((kval>(Gridmax))){printf("focWW: (xval>(Gridmax)) %20.15f %20.15f\n",kval, dxgrid);getchar();}
    if ((ixgrid>=(maxigrid-1))){printf("focWW: ixgrid>=(maxgrid-1) %d\n",ixgrid);getchar();}
    if ((cons<=0.0)){printf("focWW: consoFOC<0.0 %20.15f\t%20.15f\n",kval,cons);getchar();}
    //if ((xval<(0.0))){printf("focWW: (xval<(0.0)) %20.15f %20.15f\n",xval, dxgrid);getchar();}
    
    
    // CONTINUATION VALUE //
    temp_vf = 0.0;
    
    // NORMAL CASE //
    if(ygrid < 9){
        for(int y=0;y<maxygrid;y++) {
            index1 = inx(ixgrid, hnext, y);
            index2 = inx(ixgrid+1, hnext, y);
            
            temp_vf += PI_tot[ygrid][y]*inter1d(dxgrid,(VFnext[index1]),(VFnext[index2]));
        }
    }
    
    // IF RETIRED, HAS PROBABILITY TO DIE //
    if(ygrid >= 9){ // then if die, lose all his assets, does not care about the descendant
        for(int y=0;y<maxygrid;y++) {
            if(y <= 2){
                index1 = inx(ixgrid, hnext, y);
                index2 = inx(ixgrid+1, hnext, y);
                
                temp_vf += PI_tot[ygrid][y]*0.0; // die so don't care
            } else {
                index1 = inx(ixgrid, hnext, y);
                index2 = inx(ixgrid+1, hnext, y);
                
                temp_vf += PI_tot[ygrid][y]*inter1d(dxgrid,(VFnext[index1]),(VFnext[index2]));
            }
        }
    }
    

    valfoc = U(cons,S[sval]) + betapar*temp_vf;

    //if(valfoc < 0){printf("FOCW: %f %f %f %f %f", U(cons,S[sval]), betapar*temp_vf, kval, xgrid, dxgrid); getchar();}
    
    valfoc=-valfoc;
    
    return valfoc;
}







/****************************/
/* VALUE FUNCTION ITERATION */
/****************************/


void VFI(double *VF, double *Kopti, int *Hopti, int *Sopti){


/* INITIALIZATION OF VARS */

// GLOBAL //
int ygrid, kgrid, hgrid, hnext, sval, iter, jcountY, jcountH, jcountI, jcount, icase, bestSopti, bestHopti;
double critereVF, valfnmax, valmax, valmaxold, bestval, bestKopti, maxS, kmin, kmax, check1, coh,ksolution,ksolution1,ksolution2,valfnmax1, valfnmax2;
double tempK, Kxgrid;
int iKxgrid;


// VALUE INITIALIZATION */
double *VFnext;
VFnext = (double *) calloc((ifulldim), sizeof(double));



// initialize the structure //
struct params_H_pb params;

critereVF=1.0;
iter=0;

// boucle VFI
while ((critereVF > epsilonValue)  && (iter < maxiterVF))
{
    
    bascule(VF,VFnext,ifulldim);

    //convergence check
    critereVF=0.0;
    valmax=0.0;
    valmaxold=0.0;
    
    jcount=0;
    jcountH = 0.0;
    jcountI = 0.0;
    jcountY = 0.0;



#if OMP == 1
omp_set_dynamic(0);     // Explicitly disable dynamic teams
omp_set_num_threads(nbthread); // UiE 4 threads for all consecutive parallel regions

#pragma omp parallel
{
#pragma omp for private(params, ygrid, kgrid, hnext, hgrid, icase, sval, bestSopti, bestHopti, valfnmax, bestval, bestKopti, maxS, kmin, kmax, check1, coh,ksolution,ksolution1,ksolution2, valfnmax1, valfnmax2, tempK, Kxgrid, iKxgrid)
#endif

// STEP 1, choose the optimal k level given states and discrete choices //
for(hgrid=0;hgrid<maxhgrid;hgrid++)
{

params.VFnextST = VFnext;


// !!!! Hgrid should control how much is Kgrid first !!!! //
// meaning: you could not have save more than what you have //
// In fact if k' < 0 is bounded by f(h'), then it should also be the case for k < 0 is bounded by f(h)//
tempK = (-(1-theta)*price*H[hgrid]);
//Kxgrid = invexpspace(tempK,Gridmin,Gridmax,Echelle1,maxigrid);
Kxgrid = invlinspace(Gridmin,Gridmax,maxigrid, tempK);
iKxgrid = (int)(floor(Kxgrid));

//printf("constraint:%f, Kx=%f,  iKx=%d", (-(1-theta)*price*H[hgrid]), Kxgrid, iKxgrid); getchar();


for(kgrid=(iKxgrid+1);kgrid<maxigrid;kgrid++)
{

        
    for(ygrid=0;ygrid<maxygrid;ygrid++)
    {


            params.ygridST = ygrid;
        
            // HERE YOU START LOOKING FOR THE SOLUTION OF V(k,h,y) //
            // set first the value to be -100000 //
            
            bestval = -10000;
            bestKopti = 0;
            bestSopti = 0;
            bestHopti = 0;
        

            
            for(hnext=0; hnext<maxhgrid; hnext++)
            {
            
                params.hnextST = hnext;
                
                // restrict s <= h' if h > 0
                if(hnext > 0){maxS = hnext + 1;}else{maxS = maxhgrid;}
                
                for(sval=0;sval<maxS;sval++)
                {
                    
                    coh = min(cashonhand(kgrid, ygrid, hgrid, hnext, sval),Gridmax);
                    
                    params.cohST = coh;
                    params.svalST = sval;
                
                    if(hnext == hgrid){kmin = min(K[kgrid],(-(1-theta)*price*H[hnext]));}else{kmin = -(1-theta)*price*H[hnext];}
                    
                    kmax = coh - 0.00001; // Kmax is always given by this value, does not depend on if coh >0 or <0.
                    
                    /******** CASE CASH ON HAND IS NEGATIVE *********/
                    if(coh < 0){ // HERE WE ARE ONLY LOOKING FOR K BEING NEGATIVE !!!! //
                    
                        check1 = coh + kmin;
                        
                        if(check1 > 0){
                        
                            kmax = coh - 0.00001;
                            
                            icase = 100.0;
                            if(foc(kmin,&params) < foc(kmin+0.00001, &params)) { // because kmin is negative, need to check if increasing a bit kmin is better
                                valfnmax = foc(kmin,&params);
                                ksolution = kmin;
                                icase = 1.0;
                            } // end corner at kmin
                            else
                            {
                                if(foc(kmax,&params) < foc((kmax-0.00001), &params)) {
                                    valfnmax = foc(kmax,&params);
                                    ksolution = kmax;
                                    icase = 2.0;
                                }
                                
                                if(icase >= 100) {
                                    valfnmax = mygolden(kmin,(kmin+0.00001),kmax,TOL,ksolution,&params,foc);
                                }
                            } // end corner at kmax
                            
                        }else{ // then can not be in that coh value //
                            
                            valfnmax = 10000;
                            ksolution = 0.0;
                            
                        }

//                    if(iter == 1 && kgrid == 200){
//                    printf("GRID: %d %d %d, SOL: %f %d %d %f bestval = %f %f coh: %f  coh-k: %f  kmin=%f, kmax=%f", kgrid, ygrid, hgrid, bestKopti, bestSopti, bestHopti, valfnmax, bestval, K[kgrid], coh, coh+ksolution, kmin, kmax);getchar();
//                    printf("SOL: %f %f %f %f", foc(kmax,&params), foc(kmax-0.00001, &params), foc(0.0, &params), foc(0.00001, &params));getchar();
//                    }
                    
                    } // end condition coh < 0
                    
                    
                    /******** CASE CASH ON HAND IS POSITIVE *********/
                    // Then separate between two cases: either you borrow, either you save, choose after the best solution //
                    if(coh >= 0){
                        
                        // first do the case of a borrowing solution //
                        icase = 100.0;
                        if(foc(kmin,&params) < foc(kmin+0.00001, &params)) { // because kmin is negative, need to check if increasing a bit kmin is better
                            valfnmax1 = foc(kmin,&params);
                            ksolution1 = kmin;
                            icase = 1.0;
                        } // end corner at kmin
                        else
                        {
                            if(foc(0,&params) < foc(-0.00001, &params)) {
                                valfnmax1 = foc(0,&params);
                                ksolution1 = 0;
                                icase = 2.0;
                            }
                            
                            if(icase >= 100) {
                                valfnmax1 = mygolden(kmin,(kmin+0.00001),0,TOL,ksolution1,&params,foc);
//                                printf("I AM HERE k1=%f kmin=%f", ksolution1, kmin);getchar();
                            }
                        } // end corner at kmax
                        
                        
                        // Second fo the case of a deposit solution //
                        icase = 100.0;
                        if(foc(0,&params) < foc(0.00001, &params)) { // because kmin is negative, need to check if increasing a bit kmin is better
                            valfnmax2 = foc(kmin,&params);
                            ksolution2 = kmin;
                            icase = 1.0;
                        } // end corner at kmin
                        else
                        {
                            if(foc(kmax,&params) < foc(kmax-0.00001, &params)) {
                                valfnmax2 = foc(kmax,&params);
                                ksolution2 = kmax;
                                icase = 2.0;
                            }
                            
                            if(icase >= 100) {
                                valfnmax2 = mygolden(0,0.00001,kmax,TOL,ksolution2,&params,foc);
//                                printf("I AM HERE k2=%f kmax=%f", ksolution2, kmax);getchar();
                            }
                        } // end corner at kmax
                        
                        
                        // Third select to borrow or to deposit //
                        if(valfnmax1 < valfnmax2){
                            valfnmax = valfnmax1;
                            ksolution = ksolution1;
                        }else{
                            valfnmax = valfnmax2;
                            ksolution = ksolution2;
                        }
                     
//                        if(icase == 100){
//                        printf("I AM HERE k=%f val1=%f, val2=%f", ksolution, valfnmax1, valfnmax2);getchar();
//                        }
                        
                    } // end coh > 0
                    
                    
                    // SAVE THE VALUE AND THE SOLUTION //
                    //Kprime[inx(kgrid,hgrid,ygrid,hnext,sval)] = ksolution;
                    //smallV[inx(kgrid,hgrid,ygrid,hnext,sval)] = -valfnmax;
  
  
                    // NOW YOU SAVE THE BEST COUPLE OF SVAL AND HNEXT //
                    if((-valfnmax) > bestval){
                        bestval = -valfnmax;
                        bestKopti = ksolution;
                        bestSopti = sval;
                        bestHopti = hnext;
                    }

//                    if(iter == 6 && kgrid == 215){
//                    printf("GRID: %d %d %d, SOL: %f %d %d %f bestval = %f %f coh: %f  coh-k: %f  kmin=%f, kmax=%f, icase=%d", kgrid, ygrid, hgrid, bestKopti, bestSopti, bestHopti, valfnmax, bestval, K[kgrid], coh, coh+ksolution, kmin, kmax, icase);getchar();
//                    printf("SOL: %f %f %f %f", foc(kmax,&params), foc(kmax-0.00001, &params), foc(0.0, &params), foc(0.00001, &params));getchar();
//                    }
                    
                } // end sval
            } // end hnext

            
            // save the solution for V(k,h,y) //
            VF[inx(kgrid,hgrid,ygrid)] = bestval;
            Kopti[inx(kgrid,hgrid,ygrid)] = bestKopti;
            Hopti[inx(kgrid,hgrid,ygrid)] = bestHopti;
            Sopti[inx(kgrid,hgrid,ygrid)] = bestSopti;
        
            //if(VF[inx(kgrid,hgrid,ygrid)] > 0){printf("MISTAKE: %d %d %d %f", kgrid, hgrid, ygrid,bestval);getchar();}
        
            //if(bestKopti > 0){printf("youhou %f ", bestKopti);getchar();}
        } // end ygrid

    } // end kgrid

} // hgrid

#if OMP == 1
    } // end pragma
#endif


// FOR CONVERGENCE //
for(kgrid=0; kgrid<maxigrid; kgrid++)
{
    for(hgrid=0; hgrid<maxhgrid; hgrid++)
    {
        for(ygrid=0;ygrid<maxygrid;ygrid++)
        {
            if ((fabs(VF[inx(kgrid, hgrid, ygrid)]-VFnext[inx(kgrid, hgrid, ygrid)]))>=critereVF){jcount=inx(kgrid, hgrid, ygrid);jcountY = ygrid; jcountH = hgrid; jcountI = kgrid;valmax=VF[inx(kgrid, hgrid, ygrid)];valmaxold=VFnext[inx(kgrid, hgrid, ygrid)];}
            critereVF=(max(fabs(VF[inx(kgrid,hgrid,ygrid)]-VFnext[inx(kgrid,hgrid,ygrid)]), critereVF));
        } // end hgrid
    } // end ygrid
} // end kgrid

iter++;

printf("Rule CNVG %d\t%20.15f\t%d\t%d\t%d\t%d\t%20.15f\t%20.15f\n",iter,critereVF,jcount, jcountI, jcountY, jcountH, valmax, valmaxold);




/*******************************/
// SAVE IN FILES BY OCCUPATION //
/*******************************/


// initialize files
FILE *valfileout;



/**** WORKER ****/
valfileout=fopen(valfile, "w");

setbuf ( valfileout, NULL );

fprintf(valfileout,"%5s\t%20s\t%5s\t%5s\t%5s\t%5s\t%20s\t%20s\n","ASSET","ASSETVAL", "PROD", "HOUSE", "Hopti", "Sopti", "Kopti", "VF");
for(kgrid=0; kgrid<maxigrid; kgrid++)
{
    for(ygrid=0;ygrid<maxygrid;ygrid++)
    {
        for(hgrid=0; hgrid<maxhgrid; hgrid++)
        {
            fprintf(valfileout,"%5d\t%20.15f\t%5d\t%5d\t%5d\t%5d\t%20.15f\t%20.15f\n",kgrid, K[kgrid], ygrid, hgrid, Hopti[inx(kgrid,hgrid,ygrid)],Sopti[inx(kgrid,hgrid,ygrid)],Kopti[inx(kgrid,hgrid,ygrid)],VF[inx(kgrid,hgrid,ygrid)]);
        }
    }
}
fclose(valfileout);





}//while (critereVF > epsilonValue)






    


// FREE calloc //
free(VFnext);

}

//////////////////////////////////
// END VALUE FUNCTION ITERATION //
//////////////////////////////////


